#include<stdio.h>
int getRandom(int);
int s[9];
int set[9];
int edge[12][2]={{1,2},{1,4},{2,3},{2,5},{3,6},{4,5},{4,7},{5,6},{5,8},{6,9},{7,8},{8,9}};
int main()
{
    int i,j;
    printf(" _ _ _ _ _ _");
    for(i=0;i<6;i++)
        for(j=0;j<6;j++)
            printf("_|");
}
