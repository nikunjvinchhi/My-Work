shape Program I used direct scanf function to give the input triangle point. 

like when we run the program it shows ...

how many triangle
3
0
0
0
10
5
5
0
0
5
5
10
0
0
10
5
5
10
10

and gave output like

Polygon point is

0 0
0 10
5 5
10 0
10 10