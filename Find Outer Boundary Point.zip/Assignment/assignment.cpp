#include<iostream.h>
void findPoint(int[3][2],int[3][2]);
int calculateNCR(int,int);
int factorial(int);
int globalPoint[100][100];
int total=0;
int main(){
    cout<<"How Many Triangle\n";
    int n;
    cin>>n;
    int i,j,k;
    int point[n][3][2];
    for(j=0;j<n;j++){
        for(i=0;i<3;i++)
        for(k=0;k<2;k++){
            cin>>point[j][i][k];
        }
    }
    int c=calculateNCR(n,2);
    //printf("%d",c);
    int temp1[3][2];
    int temp2[3][2];
    int t;
    for(i=0;i<n-1;i++){
        for(j=0;j<3;j++){
            for(k=0;k<2;k++)
                temp1[j][k]=point[i][j][k];
        }
        for(t=(i+1);t<n;t++){
            for(j=0;j<3;j++){
                for(k=0;k<2;k++){
                    temp2[j][k]=point[t][j][k];
                    /*printf("%d %d\n",temp2[j][k],t);*/}
            }
            //printf("Hell's Kitchen %d %d\n",i,t);
            findPoint(temp1,temp2);

        }
    }
    //printf("%d",total);

    //Remove duplicate point
    int temp[100]={0};
    for(i=0;i<total;i++)
    {
        if(temp[i]==0){
            for(j=i+1;j<total;j++){
                if(globalPoint[i][0]==globalPoint[j][0] && globalPoint[i][1]==globalPoint[j][1]){
                    temp[j]=1;
                }
            }
     //       printf("%d %d %d\n",globalPoint[i][0],globalPoint[i][1],i);
        }
    }
    /*for(i=0;i<total;i++)
        printf("%d ",temp[i]);*/
    int temp3[n][3];
    int total_num[10];
    int counter1=0;
    int counter2=0;
    int counter=0;
    for(i=0;i<total;i++){
        if(temp[i]==0){
            counter1=0;
            counter=0;
            for(j=0;j<n;j++){
                counter2=0;
                for(k=0;k<3;k++){
                    if(globalPoint[i][0]==point[j][k][0] && globalPoint[i][1]==point[j][k][1])
                    {
                        temp3[counter1][counter2]=1;
                        counter++;
            //            printf("hello %d %d %d %d %d\n",counter1,globalPoint[i][0],globalPoint[i][1],point[j][k][0],point[j][k][1]);
                        }
                    else
                        if(temp3[counter1][counter2]!=1)
                        {    temp3[counter1][counter2]=0;}
                    counter2++;
                }
                counter1++;
            }
        total_num[i]=counter;
        }
    }
    //for(i=0;i<total;i++)
        //for(j=0;j<3;j++)
      //      printf("%d\n",total_num[i]);

    for(i=0;i<n;i++){
        for(j=0;j<3;j++){
            if(temp3[i][j]==0){
                globalPoint[total][0]=point[i][j][0];
                globalPoint[total][1]=point[i][j][1];
                temp[total]=0;
                total_num[total]=1;
                total++;
            }
        }
    }
    cout<<"Polygon Points";
    int globalPoint_final[total][2];
    for(i=0;i<total;i++){
        j=0;
        if(temp[i]==0 && total_num[i]<4){
            globalPoint_final[j][0]=globalPoint[i][0];
            globalPoint_final[j][1]=globalPoint[i][1];
            cout<<"\n";
            cout<<globalPoint_final[j][0];cout<<" ";
            cout<<globalPoint_final[j][1];
            j++;
        }
    }

    //globalpoint_final have polygon points. Now remove inner points of polygon

    return 0;
}
int calculateNCR(int a,int b){
    int fact1=factorial(a);
    int fact2=factorial(a-b);
    int ncr=fact1/(2*fact2);
    return ncr;
}
int factorial(int n){
    int f=1;
    int i;
    if(n==0)
        return f;
    for(i=1;i<=n;i++){
        f=f*i;
    }
    return f;
}
void findPoint(int a[3][2],int b[3][2]){
    int i,j;
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            if(a[i][0]==b[j][0] && a[i][1]==b[j][1]){
                globalPoint[total][0]=a[i][0];
                globalPoint[total][1]=a[i][1];
                total++;
            }
    }
}
}
