// Author:- n!k$
// 4*4.
#include<stdio.h>
#include<time.h>

int board[81]={0};
int row[81][8];
int col[81][8];
int box[81][4];
int choice;
int limit;
void create_Color();
void selection();
void generate(int);
int check(int,int);
void display_Board();
void solution(int);
int check_Board();
int main()
{
    time_t tt1;
	srand((unsigned)time(&tt1));
	create_Color();
	selection();
	display_Board();
	solution(limit);
	printf("\nSolution Is:\n");
	display_Board();
}
void create_Color ()
{
    int i,j,k=1,l,t=1,p=1,counter=1;
	for(i=1;i<=81;i++)
	{
		for(j=k;j<k+9;j++)
		{
			if(i!=j)
			{
				row[i][t]=j;
				//printf("Hello..%d %d row=%d %d\n",i,j,t,row[i][t]);
                t++;
			}
		}
		if(i%9==0)
			k=k+9;
        t=1;
		for(j=p;j<=81;j=j+9)
		{
		    if(i!=j)
		    {
                col[i][t]=j;
	            //printf("Hello..%d %d col=%d %d\n",i,j,t,col[i][t]);
                t++;
		    }
		}
		t=1;
		if(i%9==0)
            p=1;
        else
            p++;
	}
	/* The Beauty Of this program Lies Here to get Box for 9*9
	put 9 where 4 and put 10 where 5 and maintain Count for the jump
	12 to 19*/
	t=1;k=1;p=1;counter=1;
	int count=0,count1=0;
	for(i=1;i<=81;)
	{
	    p=1;
        for(j=1;j<=9;j++)
        {
            if(k!=i && (k+1)!=i && (k+2)!=i && k!=i+1 && k!=i+2 && (i%9)!=(k%9))
            {
                box[i][p]=k;
                p++;
            }
            if(k%3==0)
            {
                k=k+7;
            }
            else
                k++;
        }
        if(i%27==0)
        {
            count1++;
            count=0;
            counter=1;
            i++;
        }
        else
        {
            if(i%3==0  && counter==3)
            {
                i=i-17;
                k=i;
                count++;
                counter=1;
            }
            else if(i%3==0)
            {
                i=i+7;
             //   printf("%d heloo......",i);
                counter++;
            }
            else
            {
                i++;
            }
        }
		k=1+(count*3)+(count1*27);//Difficult
    }
    /*for(i=1;i<=81;i++)
        for(j=1;j<=4;j++)
            printf("%d\n",box[i][j]);*/
}
void selection()
{
    int choice;
    printf("Select Difficulty Level::\n");
	printf("1.Easy::\n");
	printf("2.Medium::\n");
	printf("3.Hard::\n");
	scanf("%d",&choice);
	switch(choice)
	{
	    case 1:
            generate(25);
            limit=40;
            break;
        case 2:
            generate(20);
            limit=61;
            break;
        case 3:
            generate(15);
            limit=66;
            break;
        default:
            printf("Enter Correct Choice:");
            break;
	}
}
void generate(int count)
{
    int i=0;
    int number,index;
    while(i!=count)
    {
        number=rand()%10;
        index=rand()%82;
        if(check(number,index)==1 && number!=0 && index!=0)
        {
          //  printf("%d %d %d\n",number,index,i);
            board[index]=number;
            i++;
        }
    }
}
int check(int number,int index)
{
    int i=0,j=0;
    int t=0;
    if(board[index]==0)
    {
        for(i=1;i<=8;i++)
        {
            if(board[row[index][i]]==number | board[col[index][i]]==number)
                return 0;
            else
                t++;
        }
        for(j=1;j<=4;j++)
            if(board[box[index][j]]==number)
                return 0;
            else
                t++;
        //        printf("%d.............",t);
        if(t==12)
            return 1;
        else
            return 0;
    }
    else
        return 0;
}
void display_Board()
{
    int i;
    for(i=1;i<=81;i++)
    {
        printf(" %d ",board[i]);
        if(i%27==0)
            printf("\n");
        else if(i%9==0)
            printf(" |\n");
        else
        {
            if(i%3==0)
            {
                printf(" | ");
            }
        }
    }
}
void solution(int limit)
{
    int index;
    int i=0;
    int number;
    while(i!=35)
    {
        number=rand()%10;
        index=rand()%82;
        if(check(number,index)==1 && number!=0 && index!=0)
        {
            //printf("%d %d %d\n",index,number,i);
            board[index]=number;
            i++;
        }
    }
}
